from cProfile import label
from dataclasses import dataclass
from hashlib import sha1
from itertools import count
import numpy as np
import torch
from tqdm import tqdm
from typing import List
from torchvision.utils import make_grid
from base import BaseTrainer
from utils import inf_loop
import sys
from sklearn.mixture import GaussianMixture
import operator
import random

def boduanxuanze(pred, index, cube, indice, cnt, shape_cube, num_class):
    #取每个波段组合分图10个概率中最大值maxp作为该波段组合分数，再把64个分数分别叠加到各自的3个波段上
    score = np.zeros(shape_cube[2])
    Times = np.zeros(shape_cube[2])
    #score = torch.zeros(103).to(device)
    #Times = torch.zeros(103).to(device)
    #for i in range(min(batch_size,pred.shape[0])):
    for i in range(shape_cube[2]):
        maxp = -99999  
        for j in range(num_class):
            if pred[i,j] > maxp:
                maxp = pred[i,j]
        score[i] = score[i] + maxp
    cube[indice[0],indice[1],:] = score
    cnt = cnt + 1
    #对波段的分数求平均排序从而得到最优波段
    Best_boduan = np.zeros(shape_cube[2]).astype(int)
    for i in range(0,shape_cube[2]):
        Best_boduan[i]=i        
    #用argsort排序，arrIndex为定义的排序因子，只能对np排序（tensor可先转换）,[::-1]为降序，升序不写
    arrIndex = np.array(score).argsort()
    score = score[arrIndex[::-1]]
    Best_boduan = Best_boduan[arrIndex[::-1]]    
    #先合成一个tuple即Sort排序再分开,第一行只能返回一个tensor
    #Sort = [(x,y) for x,y in sorted(zip(score, Best_boduan),reverse = True)]
    #score = [x for x,_ in Sort]
    #Best_boduan = [x for _,x in Sort]
    if index % 40 == 0:
        print('Best Boduan of picture ',index,' :',Best_boduan[0],' ',Best_boduan[1],' ',Best_boduan[2],' ',Best_boduan[3],' ',Best_boduan[4],' '
        ,' ',Best_boduan[5],' ',Best_boduan[6],' ',Best_boduan[7],' ',Best_boduan[8],' ',Best_boduan[9])
    return Best_boduan

def Bands_create(ori_data, ori_label, i, indexs, indices, shape_cube, shape_patch):

    img = ori_data[i,:,:,:]
    label = torch.zeros(shape_cube[2]).cuda()
    #boduan = torch.zeros(103).cuda()
    index = np.zeros(shape_cube[2])
    data = torch.zeros((shape_cube[2],3,shape_patch,shape_patch)).cuda()
    for j in range(shape_cube[2]):
        data[j,0,:,:] = img[j,:,:]
        data[j,1,:,:] = img[j,:,:]
        data[j,2,:,:] = img[j,:,:]
        label[j] = ori_label[i]
        index[j] = indexs[i]
    index = index.astype(int)
    indice = indices[i]
    return data, label, index ,indice

class Trainer(BaseTrainer):
    """
    Trainer class

    Note:
        Inherited from BaseTrainer.
    """
    def __init__(self, model, train_criterion, metrics, optimizer, config, data_loader,
                 valid_data_loader=None, test_data_loader=None, lr_scheduler=None, len_epoch=None, val_criterion=None):
        super().__init__(model, train_criterion, metrics, optimizer, config, val_criterion)
        self.config = config
        self.data_loader = data_loader
        if len_epoch is None:
            # epoch-based training
            self.len_epoch = len(self.data_loader)
        else:
            # iteration-based training
            self.data_loader = inf_loop(data_loader)
            self.len_epoch = len_epoch
        self.valid_data_loader = valid_data_loader

        self.test_data_loader = test_data_loader
        self.do_validation = self.valid_data_loader is not None
        self.do_test = self.test_data_loader is not None
        self.lr_scheduler = lr_scheduler
        self.log_step = int(np.sqrt(data_loader.batch_size))
        self.train_loss_list: List[float] = []
        self.val_loss_list: List[float] = []
        self.test_loss_list: List[float] = []
        #Visdom visualization
        
    def _eval_metrics(self, output, label):
        acc_metrics = np.zeros(len(self.metrics))
        for i, metric in enumerate(self.metrics):
            acc_metrics[i] += metric(output, label)
            self.writer.add_scalar('{}'.format(metric.__name__), acc_metrics[i])
        return acc_metrics
    
    def _train_epoch(self, epoch):
        """
        Training logic for an epoch

        :param epoch: Current training epoch.
        :return: A log that contains all information you want to save.

        Note:
            If you have additional information to record, for example:
                > additional_log = {"x": x, "y": y}
            merge it with log before return. i.e.
                > log = {**log, **additional_log}
                > return log

            The metrics in log must have the key 'metrics'.
        """
        shape_cube = self.data_loader.dataset.data.shape
        cube = np.zeros((shape_cube[0],shape_cube[1],shape_cube[2]))#cube:610*340*103
        img = self.data_loader.dataset.data
        cnt = 0

        self.model.train()#让model变成训练模式
        #print('self.model=',self.model)
        total_loss = 0
        total_metrics = np.zeros(len(self.metrics))
        Best_band = np.zeros((len(self.data_loader.dataset.indices),shape_cube[2])).astype(int)
        self.cubelist = []
        with tqdm(self.data_loader) as progress:
            #for是迭代的轮次N而不是执行getitem的次数即batchsize,N次迭代都在一个epoch里。N*batchsize=总的图片数
            for batch_idx, (ori_data, ori_label, indexs, indices) in enumerate(progress):
                
                progress.set_description_str(f'Train epoch {epoch}')#设置/修改进度条的提示
                ori_data = ori_data.type(torch.cuda.FloatTensor)
                                
                ori_data, ori_label = ori_data.to(self.device), ori_label.long().to(self.device)
                #.to(self.device)=.cuda()
                

                for i in range(ori_data.shape[0]):
                    
                    data, label ,index, indice = Bands_create(ori_data, ori_label, i, indexs, indices, shape_cube, self.data_loader.dataset.patch_size)
                    #再用每个波段都生成一张图共103张图  
                    # data:103*3*27*27 label:103,同一patch标签相同 index:103,同一patch序号相同 indice:[x,y]
                    
                    label = label.long()
                    output = self.model(data)
                    #output是得到的10个特征而不是10个概率
                    index = torch.from_numpy(index)
                    loss,pred = self.train_criterion(index.cpu().detach().numpy().tolist(), output, label)
                    #index.xxxxxx:tensor格式的数据改成numpy 计算loss时forward
                    #print('model=',self.model)
                    
                    Best_bandi = boduanxuanze(pred, np.array(indexs[i]), cube, indice, cnt, shape_cube, self.data_loader.dataset.num_class)
                    Best_band[indexs[i]] = Best_bandi
                    
                    self.optimizer.zero_grad()#先将梯度归零optimizer.zero_grad()
                    loss.backward()#然后反向传播计算得到每个参数的梯度值loss.backward()
                    self.optimizer.step()#最后通过梯度下降执行一步参数更新optimizer.step()

                    self.writer.set_step((epoch - 1) * self.len_epoch + batch_idx)#从命名来看就是记你训到哪了
                    self.writer.add_scalar('loss', loss.item())
                    self.train_loss_list.append(loss.item())
                    total_loss += loss.item()
                    total_metrics += self._eval_metrics(output, label)

                    if batch_idx % self.log_step == 0:
                        progress.set_postfix_str(' {} Loss: {:.6f}'.format(
                            self._progress(batch_idx),
                            loss.item()))
                        self.writer.add_image('input', make_grid(data.cpu(), nrow=8, normalize=True))

                    if batch_idx == self.len_epoch:
                        break
        # if hasattr(self.data_loader, 'run'):
        #     self.data_loader.run()

        log = {
            'loss': total_loss / self.len_epoch,
            'metrics': (total_metrics / self.len_epoch).tolist(),
            'learning rate': self.lr_scheduler.get_lr(),
            'Best_band': Best_band,
            'cube': cube
        }
        '''
        if self.do_validation:
            val_log = self._valid_epoch(epoch)
            log.update(val_log)
        if self.do_test:
            test_log, test_meta = self._test_epoch(epoch)
            log.update(test_log)
        else: 
            test_meta = [0,0]
        '''

        if self.lr_scheduler is not None:
            self.lr_scheduler.step()

        return log  #包含val和train返回一共7个值

    def _warmup_epoch(self, epoch):
        total_loss = 0
        total_metrics = np.zeros(len(self.metrics))
        self.model.train()

        data_loader = self.data_loader#self.loader.run('warmup')


        with tqdm(data_loader) as progress:
            for batch_idx, (data, label, _, indexs , _) in enumerate(progress):
                progress.set_description_str(f'Warm up epoch {epoch}')

                data, label = data.to(self.device), label.long().to(self.device)

                self.optimizer.zero_grad()
                output = self.model(data)
                out_prob = torch.nn.functional.softmax(output).data.detach()

                self.train_criterion.update_hist(indexs.cpu().detach().numpy().tolist(), out_prob)

                loss = torch.nn.functional.cross_entropy(output, label)

                loss.backward() 
                self.optimizer.step()

                self.writer.set_step((epoch - 1) * self.len_epoch + batch_idx)
                self.writer.add_scalar('loss', loss.item())
                self.train_loss_list.append(loss.item())
                total_loss += loss.item()
                total_metrics += self._eval_metrics(output, label)


                if batch_idx % self.log_step == 0:
                    progress.set_postfix_str(' {} Loss: {:.6f}'.format(
                        self._progress(batch_idx),
                        loss.item()))
                    self.writer.add_image('input', make_grid(data.cpu(), nrow=8, normalize=True))

                if batch_idx == self.len_epoch:
                    break
        if hasattr(self.data_loader, 'run'):
            self.data_loader.run()
        log = {
            'loss': total_loss / self.len_epoch,
            'noise detection rate' : 0.0,
            'metrics': (total_metrics / self.len_epoch).tolist(),
            'learning rate': self.lr_scheduler.get_lr()
        }

        if self.do_validation:
            val_log = self._valid_epoch(epoch)
            log.update(val_log)
        if self.do_test:
            test_log, test_meta = self._test_epoch(epoch)
            log.update(test_log)
        else: 
            test_meta = [0,0]

        return log


    def _progress(self, batch_idx):
        base = '[{}/{} ({:.0f}%)]'
        if hasattr(self.data_loader, 'n_samples'):
            current = batch_idx * self.data_loader.batch_size
            total = self.data_loader.n_samples
        else:
            current = batch_idx
            total = self.len_epoch
        return base.format(current, total, 100.0 * current / total)